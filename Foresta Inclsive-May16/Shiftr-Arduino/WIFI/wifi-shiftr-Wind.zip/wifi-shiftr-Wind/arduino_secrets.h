#define SECRET_SSID "Evol"
#define SECRET_PASS "5138loove"

#define MQTT_NAMESPACE "Foresta-Inclusive-WIFIWind1" //"kintel-wifi"
#define MQTT_USERNAME "83aa4496" //"66ddedc6"
#define MQTT_PASSWORD "02ffd19115bcd0ed" //"fe2d57914c828f0b"
